import './CustomTheme/_color/Theme_color_myThemeDefault.css';


export const customThemePreset = {
  color: {
    primary: 'myThemeDefault',
  },
};
